"""csci3302_lab2 controller."""
"""Alex Book and Justin Vuong"""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
import math
from controller import Robot, Motor, DistanceSensor

# Ground Sensor Measurements under this threshold are black
# measurements above this threshold can be considered white.
# TODO: Fill this in with a reasonable threshold that separates "line detected" from "no line detected"
GROUND_SENSOR_THRESHOLD = 0

# These are your pose values that you will update by solving the odometry equations
pose_x = 0
pose_y = 0
pose_theta = 0

# Constants to help with the Odometry update
WHEEL_FORWARD = 1
WHEEL_STOPPED = 0
WHEEL_BACKWARD = -1

# Index into ground_sensors and ground_sensor_readings for each of the 3 onboard sensors.
LEFT_IDX = 0
CENTER_IDX = 1
RIGHT_IDX = 2

state = "speed_measurement"

# create the Robot instance.
robot = Robot()

# ePuck Constants
EPUCK_AXLE_DIAMETER = 0.053 # ePuck's wheels are 53mm apart.
EPUCK_MAX_WHEEL_SPEED = .13/2 # To be filled in with ePuck wheel speed in m/s

# get the time step of the current world.
SIM_TIMESTEP = int(robot.getBasicTimeStep())

# Initialize Motors
leftMotor = robot.getMotor('left wheel motor')
rightMotor = robot.getMotor('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# Initialize and Enable the Ground Sensors
ground_sensor_readings = [0, 0, 0]
ground_sensors = [robot.getDistanceSensor('gs0'), robot.getDistanceSensor('gs1'), robot.getDistanceSensor('gs2')]
for gs in ground_sensors:
    gs.enable(SIM_TIMESTEP)


def update_odometry(left_wheel_direction, right_wheel_direction, time_elapsed):
    '''
    Given the amount of time passed and the direction each wheel was rotating,
    update the robot's pose information accordingly
    '''
    global pose_x, pose_y, pose_theta, EPUCK_MAX_WHEEL_SPEED, EPUCK_AXLE_DIAMETER

    # equation 3.36
    x_r = EPUCK_MAX_WHEEL_SPEED*(right_wheel_direction+left_wheel_direction)/2

    # equation 3.39
    theta = EPUCK_AXLE_DIAMETER*(right_wheel_direction-left_wheel_direction)/EPUCK_AXLE_DIAMETER

    # equation 3.40
    x_i = x_r*math.cos(pose_theta)
    y_i = x_r*math.sin(pose_theta)

    # equations 3.41 and 3.42
    pose_theta += theta*time_elapsed
    pose_x += x_i*time_elapsed
    pose_y += y_i*time_elapsed

def main():
    global robot, ground_sensors, ground_sensor_readings, state
    global leftMotor, rightMotor, SIM_TIMESTEP, WHEEL_FORWARD, WHEEL_STOPPED, WHEEL_BACKWARDS, EPUCK_MAX_WHEEL_SPEED
    global pose_x, pose_y, pose_theta

    measurement_start_time = None

    # Part 2 & 3 Variables
    last_odometry_update_time = None
    loop_closure_detection_time = None

    # Variables to keep track of which direction each wheel is turning for odometry
    left_wheel_direction = WHEEL_STOPPED
    right_wheel_direction = WHEEL_STOPPED

    # Allow sensors to properly initialize
    for i in range(10): robot.step(SIM_TIMESTEP)

    firstTimeThrough = True

    # Main Control Loop:
    while robot.step(SIM_TIMESTEP) != -1:

        # Read ground sensor values
        for i, gs in enumerate(ground_sensors):
            ground_sensor_readings[i] = gs.getValue()

        left = ground_sensor_readings[0]
        center = ground_sensor_readings[1]
        right = ground_sensor_readings[2]

        if state == "speed_measurement":
            leftMotor.setVelocity(leftMotor.getMaxVelocity()/2)
            rightMotor.setVelocity(rightMotor.getMaxVelocity()/2)
            if firstTimeThrough == True:
                measurement_start_time = robot.getTime()
                firstTimeThrough = False
            else:
                if left <= 700 and center <= 700 and right <= 700:
                    travelTime = robot.getTime()-measurement_start_time
                    print("Time to get to start line:", travelTime)
                    leftMotor.setVelocity(0)
                    rightMotor.setVelocity(0)
                    state = "line_follower"
                    left_wheel_direction = WHEEL_FORWARD
                    right_wheel_direction = WHEEL_STOPPED

        elif state == "line_follower":

            # If first time entering this state ever, just take the current time as "last odometry update" time
            if last_odometry_update_time is None:
                last_odometry_update_time = robot.getTime()

            # TODO: Call update_odometry Here
            time_elapsed = robot.getTime()-last_odometry_update_time
            update_odometry(left_wheel_direction, right_wheel_direction, time_elapsed)
            last_odometry_update_time = robot.getTime()

            # TODO: Insert Line Following Code Here
            if center <= 700:
                leftMotor.setVelocity(leftMotor.getMaxVelocity()/2)
                left_wheel_direction = WHEEL_FORWARD
                rightMotor.setVelocity(rightMotor.getMaxVelocity()/2)
                right_wheel_direction = WHEEL_FORWARD
            elif left <= 700:
                leftMotor.setVelocity(-leftMotor.getMaxVelocity()/2)
                left_wheel_direction = WHEEL_BACKWARD
                rightMotor.setVelocity(rightMotor.getMaxVelocity()/2)
                right_wheel_direction = WHEEL_FORWARD
            elif right <= 700:
                leftMotor.setVelocity(leftMotor.getMaxVelocity()/2)
                left_wheel_direction = WHEEL_FORWARD
                rightMotor.setVelocity(-rightMotor.getMaxVelocity()/2)
                right_wheel_direction = WHEEL_BACKWARD
            else:
                leftMotor.setVelocity(-leftMotor.getMaxVelocity()/2)
                left_wheel_direction = WHEEL_BACKWARD
                rightMotor.setVelocity(rightMotor.getMaxVelocity()/2)
                right_wheel_direction = WHEEL_FORWARD

            if left <= 700 and center <= 700 and right <= 700 and (pose_y >= -.15 and pose_y <= .15):
                if loop_closure_detection_time is None:
                    loop_closure_detection_time = robot.getTime()
            else:
                if loop_closure_detection_time is not None:
                    delta_t = robot.getTime() - loop_closure_detection_time
                    if delta_t > .4 and (pose_y >= -.15 and pose_y <= .15):
                        pose_x, pose_y, pose_theta = 0, 0, 0
                        loop_closure_detection_time = None

            print("Current pose: [%5f, %5f, %5f]" % (pose_x, pose_y, pose_theta))

        else:
            pass


if __name__ == "__main__":
    main()
